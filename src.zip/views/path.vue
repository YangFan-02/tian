<template>
    <div>
        <mt-header title="地址管理" fixed>
            <div slot="left">
                <router-link to="/" class="header">
                    <img src="../assets/images/back.png" id="back">
                </router-link></div>
            <mt-button slot="right" icon="more"><router-link to="/address" class="header">添加新地址</router-link></mt-button>
        </mt-header>
        <!-- <mt-tab-container> -->
            <!-- <mt-cell isLink to="/"  class="cell"> -->
                <div class="path" v-for="(item,index) of path" :key="index">
                    <b>{{item.receiver}}</b>
                    <span>{{item.cellphone}}</span><br>
                    <p>{{item.address}}</p>
                </div>
            <!-- </mt-cell> -->
        <!-- </mt-tab-container> -->
    </div>
</template>
<style  scoped>
/* 顶部导航栏样式 */
    .header{
        color: #ffffff;
        text-decoration: none;
        margin-right: 10px;
    }
    /* 面板区域样式 */
    .path{
        width: 100%;
        height: 60px;
        position: relative;
        top: 50px;
        border: 1px solid #dddddd;
        margin-bottom:5px ;
    }
    .path b,span{
        font-size: 14px;
        margin-left: 5px;
        position: relative;
        top: 5px;
        left: 10px;
    }
    .path p{
        position: relative;
        font-size: 15px;
        margin: 12px 0;
        left: 10px;
    }
</style>>
<script>
export default {
    data(){
        return{
            path:[]
        }
    },
    mounted(){
        this.axios.get('/path').then((res)=>{
            this.path = res.data.results;
        })
    }
}
</script>