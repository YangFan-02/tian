<template>
    <div>
        <div>
            <mt-header  title="个人设置" fixed class="head">
                <router-link to="/me" slot="left">
                    <mt-button icon="back"></mt-button>
                </router-link>
            </mt-header>
        </div>
        <div>
            <mt-tab-container>
                <div class="div_11">
                    <div class="first">
                        <div class="headNike">
                            <img src="../assets/logo.png" alt="">
                        </div>
                        <div class="right_head">
                            <p class="first_p">昵称</p>
                            <p><a href="">会员号:1234567</a></p>
                        </div>
                    </div>
                </div> 
                <div class="wto">
                    <mt-cell title="收获地址管理" isLink to="/path">
                        
                    </mt-cell>
                    <mt-cell title="关于我们" isLink to="">
                        
                    </mt-cell>
                     <mt-cell title="服务协议" isLink to="">

                    </mt-cell>
                </div>               
            </mt-tab-container>
            <div>
                <mt-button size="large">退出登录</mt-button>
            </div>
        </div>
    </div>
</template>
<style scoped>
    .head{
        background-color:#000 !important;
    }
    .div_11{
        width:100%;
        height:140px;
    }
    .first{
        margin-top:40px;
        width: 100%;
        height:100px;


    }
    .headNike{
        width:60px;
        height:60px;
        border: 1px solid #ccc;
        border-radius:100%;
        margin-top: 50px;
        margin-left: 40px;
  
    }
    /**头像 */
    .headNike img{
        width:60px;
        height:60px;
        border-radius: 100%;
    }
    /**昵称会员区域 */
    .right_head{
        width:400px;
        height:60px;
        margin-left: 120px;
        margin-top:-50px;   
    }
    .first_p{
        margin-top:10px;
        margin-bottom: 10px;
    }
     .right_head a{
         text-decoration: none;
     }
     .wto{
         width: 100%;
        height:150px;
        margin-top:150px;
        margin-left: -365px;
         
        
     }
</style>
