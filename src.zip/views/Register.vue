<template>
  <div>
    <!-- 顶部导航 -->
    <mt-header title="注册">
      <router-link to="me" slot="left">
        <mt-button icon="back"></mt-button>
      </router-link>
    </mt-header>    
    <h1 class="text">请输入手机号,加入蟹老板</h1>
    <!-- 用户名 -->
    <mt-field
      class="field"
      type="text"
      :state="usernameState"
      style="border:1px solid #ccc;margin:10px 10px 0 10px"
      placeholder="请输入用户名/邮箱/手机号"
      @blur.native.capture="checkUsername"
      disableClear
      v-model="username">
    </mt-field>
    <!-- 密码框 -->
    <mt-field
      type="password"
      placeholder="密码"
      :state="passwordState"
      style="border:1px solid #ccc;margin:10px 10px 0 10px"
      :attr="{maxlength:'20',autocomplete:'off'}"
      v-model="password"
      @blur.native.capture="checkPassword"
    ></mt-field>
    <mt-field
      type="password"
      placeholder="请确认密码"
      :state="passwordState2"
      style="border:1px solid #ccc;margin:10px"
      :attr="{maxlength:'20',autocomplete:'off'}"
      v-model="password2"
      @blur.native.capture="checkPassword2"
    ></mt-field>
    <!-- 注册文本框结束 -->
    <!-- 手机验证码开始 -->
    <!-- <mt-field
      type="text"
      placeholder="输入手机号"
      style="border:1px solid #ccc;margin:10px 10px 0 10px"
      state="phoneState"
      disableClear
      v-model="phone"
      @blur.native.capture="checkPhone">
      </mt-field>
    //手机验证码结束
     //验证码输入框开始
    <mt-field
      type="number"
      placeholder="输入验证码"
      style="border:1px solid #ccc;margin:20px 10px"
      state="codeState"
      disableClear
      v-model="codenumber"
      @blur.native.capture="checkCode"
    >
      //<mt-button type="danger" size="small" @click ="code">获取验证码</mt-button> 
    <span class="codetxt" type="button" :disabled="disabled" @click="code">&nbsp;&nbsp;|&nbsp;&nbsp;{{btntxt}}</span>
    </mt-field> -->
    <!-- 验证码输入框结束 -->
    <!-- 注册按钮 -->
    <mt-button type="danger" size="large" @click ="handle">快速注册</mt-button>
  </div>
</template>
<script>
export default {
  data(){
    return{
      // 手机号的初始值
      phone:"",
      // 验证码的初始值
      codenumber:"",
      // 手机号输入框的状态
      phoneState:"",
      // 验证码输入框的状态
      codeState:"",
      // 验证码的值
      btntxt:"获取验证码",
      // 禁用状态
      disabled:false,
      // 倒计时
      time:0,
       // 用户名的初始值
      username:'',
      // 密码的初始值
      password:'',
      //确认密码的初始值
      password2:'',
      // 用户名输入框的状态
      usernameState:'',
      // 密码输入框的状态
      passwordState:'',
      //确认密码输入框的状态
      passwordState2:''
    }
  },
  methods:{
     checkUsername(){
      let usernameRexExp = /^[a-zA-Z0-9_]{6,12}$/;
      if(usernameRexExp.test(this.username)){
        this.usernameState = 'success';
        return true;
      }else{
        this.usernameState = 'error';
        this.$toast({
          message:"用户名错误",
          position:"middle",
          duration:5000
        });
        return false;
      }
    },

      // 检测密码
      checkPassword(){
      let passwordRegExp = /^[a-zA-Z0-9_]{6,20}$/;
      if (passwordRegExp.test(this.password)) {
        this.passwordState = "success";
        return true;
      } else {
        this.passwordState = "error";
        this.$toast({
          message: "密码错误",
          position: "middle",
          duration: 3000
        });
        return false;
        }
      },
      checkPassword2(){
        if(this.password == this.password2){
          this.passwordState2="success"
          return true;
        }else{
          this.$toast({
            message:"两次密码不一致",
            position:"middle",
            duration:3000
          });
          return false;
        }
      },
    // checkPhone(){
    //   // 1.校验手机号是否合法,规则为:1-11位的数字组成
    //   let phoneRegExp = /^((13[0-9])|(15[^4,\\D])|(18[0,0-9]))\\d{8}$/;
    //   if(phoneRegExp.test(this.phone)){
    //     this.phoneState = 'success';
    //     this.disabled=true;
    //     return true;
    //   } else {
    //     this.phoneState = 'error';
    //     this.$toast({
    //       message:'手机号输入不正确',
    //       position:'middle',
    //       duration:3000
    //     });
    //     return false;
    //   }
    // },
    // //验证验证码正确性
    // checkCode(){
    //   // 校验手机号是否正确,规则为4为数字
    //   let codenumberRegExp = /$\d{4}$/;
    //   if(codenumberRegExp.test(this.codenumber)){
    //     return true;
    //   } else{
    //     this.$toast({
    //       message:'验证码不正确',
    //       position:'middle',
    //       duration:3000
    //     });
    //     return false;
    //   }
    // },
    // // 验证手机号码格式正确后才能点击 获取验证码按钮

    // code(){
    //   if (this.time > 0) {
    //     this.time--;
    //     this.btntxt = this.time + "s后获取";
    //     setTimeout(this.timer, 1000);
    //   } else {
    //     this.time = 0;
    //     this.btntxt = "获取验证码";
    //     this.disabled = false;
    //   }
    // },
    // 提交注册按钮    
    // 单击按钮时完成用户注册的信息的校验
    handle(){
          if(this.checkUsername() && this.checkPassword() && this.checkPassword2()){
            this.axios.post('/register','username='+this.username+'&password='+this.password).then((res)=>{
                if(res.data.code == 0){
                  this.$messagebox("注册提示","用户名已存在");
                }else{
                  this.$router.push('/');
                }
            })
          }else{
            this.$messagebox("错误","两次密码输入不一致")
          }
        }
      }
    }
</script>
<style scoped>
.text{
  font-size: 20px;
  text-align: center;
  color: #211d1d;
  margin-top: 30px;
}
</style>