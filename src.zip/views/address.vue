<template>
    <div class="container">
        <mt-header title="新增地址" fixed id="header">
            <div slot="left">
                <router-link to="/path" class="header">
                    <img src="../assets/images/back(b).png" id="back">
                </router-link>
            </div>
        </mt-header>
        <div id="tab">
            <mt-field type="text" 
            label="收货人" 
            placeholder="请输入有效姓名"
            @blur.native.capture="checkReceiver"
            disableClear
            v-model="receiver">
                <img src="../assets/images/right.png" alt="">
            </mt-field>
            <mt-field type="number" 
            label="联系电话" 
            placeholder="请输入有效联系电话"
            disableClear
            v-model="cellphone"
            @blur.native.capture="checkPhone">
                <img src="../assets/images/right.png" alt="">
            </mt-field>
            <mt-field type="text" label="所在地区" placeholder=""><img src="../assets/images/right.png" alt=""></mt-field>
            <mt-field type="text" 
            label="详细地址" 
            placeholder="请详细填写收货地址"
            v-model="address"
           :attr="{maxlength:'40'}"
           @blur.native.capture="checkAddress">
                <img src="../assets/images/right.png" alt="">
            </mt-field>
            <mt-button size="normal" @click="handle" plain class="btn">添加地址</mt-button>
        </div>

    </div>
</template>
<style scoped>
    /* 头部样式 */
    #header{
        background-color: white;
        color: black;
        font-size:16px;
    }
     /* 内容区域样式 */
    .container{
        width: 100%;
        height: 400px;
        background-color: #f3f3f3;
        border: 0;
    }
    #tab{
        width: 100%;
        height: 90px;
        background-color: white;
        position: relative;
        top: 55px; 
        left: -1px;
        border: 0;   
       }
       #tab mt-field{
           padding-left:5px ;
       }
       .btn{
           width: 100%;
           margin-top: 20px;
       }
       .mint-button--default.is-plain{
            border: 0;
            background-color: #ffffff;
       }
</style>
<script>
export default {
    data(){
        return{
            //收货人姓名初始值
            receiver:'',
            //收货人电话初始值
            cellphone:'',
            //收货人详细地址初始值
            address:''
        }
    },
    methods:{
        //检测姓名
        checkReceiver(){
            let receiverRexExp = /^[\u4e00-\u9fa5a-zA-Z0-9]{2,8}$/;
            if(receiverRexExp.test(this.receiver)){
                return true;
            }else{
                this.$toast({
                    message:"用户名错误",
                    position:"middle",
                    duration:5000
                });
                return false;
            }
        },
        //检测电话
        checkPhone(){
            let phoneRegExp = /^1[3-9]\d{9}$/;
            if(phoneRegExp.test(this.cellphone)){
                return true;
            }else{
                this.$toast({
                    message:"手机号码输入不正确",
                    position:"middle",
                    duration:5000
                })
                return false;
            }
        },
        checkAddress(){
            let AddressRexExp = /^[\u4e00-\u9fa5a-zA-Z0-9]{10,40}$/;
                if(AddressRexExp.test(this.address)){
                    return true;
                }else{
                    this.$toast({
                        message:"地址格式输入错误",
                        position:"middle",
                        duration:4000
                    })
                    return false;
                }
            },
        handle(){
            if(this.checkReceiver() && this.checkPhone() && this.checkAddress()){
                this.axios.post('/address',"receiver="+this.receiver+"&cellphone="+this.cellphone+"&address="+this.address)
                .then((res)=>{
                    if(res.data.code == 1){
                        this.$messagebox("提示","添加成功")
                        this.$router.push('/path');
                    }else{
                        this.$messagebox("错误","信息输入不完整")
                    }
                })
            }
        }
    }
}
</script>