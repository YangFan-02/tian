<template>
      <div>
        
          <!-- 顶部搜索框开始 -->
          
            <div class="div_sech" fixed>
            <router-link to="/search" class="search_to">
                <form action="" target="frameFile">
                <mt-search v-model="value" cancel-text="搜索"  placeholder="搜索" @keyup.enter.native="searchData">
                </mt-search></form>
            </router-link>
              <iframe name='frameFile' style="display: none;"></iframe>
         </div>
       <!--顶部搜索框结束  -->
       <!--顶部选项开始 -->
          <div class="second">
            <ul>
              <li>
                <img src="../assets/asset/美食.png">
                <p>美食</p>
              </li>
             <li>
                <img src="../assets/asset/饮品.png">
                <p>饮品</p>
              </li>
              <li>
                <img src="../assets/asset/超市.png">
                <p>超市</p>
              </li>
              <li>
                <img src="../assets/asset/精选.png">
                <p>精选</p>
              </li>
            </ul>
          </div>
          <div class="seconds">
              <ul>
              <li>
                <img src="../assets/asset/水果.png">
                <p>生鲜果蔬</p>
              </li>
             <li>
                <img src="../assets/asset/全部.png">
                <p>全部商家</p>
              </li>
              <li>
                <img src="../assets/asset/免费.png">
                <p>免费配送</p>
              </li>
              <li>
                <img src="../assets/asset/新.png">
                <p>新商家</p>
              </li>
            </ul>
          </div>
       <!--顶部选项结束  -->
       <!--轮播图开始  -->
      <div class="secondas">
         <mt-swipe :auto=4000 :showIndicators="true" class=" mint-swipe">
          <mt-swipe-item class="mint-swipe-item" v-for="(carousel,index) of carousels" :key="index">
            <router-link :to="`${carousel.href}`">
              <img v-lazy="carousel.img" alt="" class="swipe_img1">
            </router-link>
        </mt-swipe-item>
      </mt-swipe>
    </div>
      <!--轮播图结束  -->
       <!--内容分栏开始  -->
        <div class="third">
          <div class="thirds">
            <div class="divsa"></div>
            <h2> —— 附近商家 ——</h2>
          </div>
        </div>
       <!--内容分栏结束  -->

      <!-- 内容选项卡开始 -->
      <!-- 顶部开始 -->
      <div class="fixed">
        <mt-navbar v-model="active">
            <mt-tab-item :id="String(item.nid)" 
              v-for="(item,index) of nav" :key="index"
            >{{item.nav_name}}</mt-tab-item>
            
        </mt-navbar>
      </div>
      <!-- 顶部结束 -->
      <!-- 面板开始 -->
      <mt-tab-container v-model="active">
          <mt-tab-container-item :id="active">
              <div v-for="(inde,index) of indexs" :key="index">
                <div class="infoItemContent">
                 <router-link :to="`/min/${inde.fid}`">
                    <img class="infoItemImg" v-lazy="inde.images" alt=""  />
                 </router-link>
                  <div class="infoItemDes">
                    <span class="foura">{{inde.fname}}</span><br>
                    <span >月售{{inde.saless}}</span>
                    <span class="fours">{{inde.address}}</span><br>
                    <span>营业时间:{{inde.hours}}</span>
                  </div>
                </div>
              </div>
          </mt-tab-container-item>
      </mt-tab-container>
      <!-- 面板结束 -->
      <!-- 内容选项卡结束 -->
        <div>
          <tabbar :selected="selected"></tabbar>
        </div>
      </div>
</template>
<style scoped>
.search_to{
  text-decoration: none;
}
.container{
  margin-top:40px;
}
.first{
    background: ghostwhite;
    height: 200px;
}
.second {
 position: relative;

 margin-top:-12px ;
}
.second ul li{
  list-style: none;
  float: left;
  text-align: center;
  margin-left: 24px;
  
}
.second ul li img{
  height: 50px;
  width: 55px;
}
.seconds {
 position: relative;
 
 margin-top:90px ;
}
.seconds ul li{
  list-style: none;
  float: left;
  text-align: center;
  margin-left: 18px;
  
}
.seconds ul li img{
  height: 50px;
  width: 55px;
}
.secondas{
  margin-top: 10px;
}
p{
  padding: 0;
  margin: 0;
  font-family: fantasy;
  color: rgb(172, 172, 172);
}
/* 附近商家 */
.third{
  width: 100%;
  height: 60px;
  line-height: 60px;
  background: ghostwhite;
}
.thirds{
  color: rgb(114, 113, 113);
  text-align: center;
}
.divsa{
height:1px;
border-bottom:1px solid ghostwhite;
overflow:hidden;
}
/*内容*/
.infoItemContent {
  display: flex;
  padding-top: 11px;
  align-items: center;
  width: 100%;
}
.infoItemImg {
  height:80px;
  width: 112px;
  margin-left: 10px;
  border-radius: 5px;
  background: #ccc;
  margin-right: 15px;
}
.infoItemDes {
  font-size: 15px;
  overflow: hidden;
  font-weight: 400;
  text-overflow: ellipsis;
  line-height: 21px;
  letter-spacing: normal;
  color: #444;
  margin: 4px 15px 4px 0;
  height: 95px;
}
img[lazy="loading"] {
  height: 75px;
}
.foura{
  font-size: 20px;
}
.fours{
  display: inline-block;
  width: 120px;
  height: 20px;
  overflow: hidden;
  margin-left: 30px;
  font-size:12px;

}
/*  轮播图*/
.mint-swipe{
  width: 90%;
  height: 150px;
  margin: 15px auto;
  margin-top: 190px;
}
.swipe_img1{
  width: 100%;
  height: 150px;
  border-radius: 20px;
}
</style>
<script>
import Tabbar from '../components/Tabbar.vue'
export default {
  components:{
    Tabbar
  },
  data(){
    return {
      active:'1',
      value:'',
      selected:'index',
      //存储服务器返回首页类型的数据
      nav:[],
      //存储服务器返回的商家数据
      indexs:[],
      //轮播图数据
      carousels:[],
    }
  },
  watch:{
     active(){
        this.indexs=[];
         this.axios.get('/index?nid=' + this.active).then(res=>{
           //将服务器返回的数据存储在变量data中
           let data = res.data.results;
           data.forEach(item=> {
             if(item.images !=null){
              item.images = require('../assets/img/' +item.images);
             }
             this.indexs.push(item);
           });
         })
     }
  },
  mounted(){
    //获取轮播图数据
    this.axios.get('/carousel').then((res)=>{
     let data = res.data.results;
        data.forEach(item => {
             if(item.img !=null){
              item.img = require('../assets/asset/' + item.img);
             }
             this.carousels.push(item);

        });
    });
    //获取顶部选项卡的数据
    this.axios.get('/index_nav').then((res) =>{
      //接受服务器返回的结果
      this.nav = res.data.results; 
    });
    //获取默认顶部选项卡包含的商品数据
     this.axios.get('/index?nid='+ this.active).then((res)=>{
       let data = res.data.results;
        data.forEach(item => {
             if(item.images !=null){
              item.images = require('../assets/img/' + item.images);
             }
             this.indexs.push(item);
           });
    });

  }
}
</script>
