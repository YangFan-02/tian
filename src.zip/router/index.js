import Vue from 'vue'
import VueRouter from 'vue-router'
import Index from '../views/Index.vue'
import Min from '../views/min.vue'
import Me from '../views/Me.vue'
// 子组件文件
import Tabbar from '../components/Tabbar.vue'
import Login from '../views/Login.vue'
import OrderForm from '../views/OrderForm.vue'
import Firste from '../views/firste.vue'
import Setting from '../views/setting.vue'
import Register from '../views/Register.vue'
import Lets from '../views/lets.vue'
import Senst from '../views/senst.vue'
import Invitation from '../views/invitation.vue'
import Path from '../views/path.vue'
import Address from '../views/address.vue'
import News from '../views/news.vue'
import Search from '../views/search.vue'
Vue.use(VueRouter)

const routes = [
  {
    path:'/search',
    component:Search
  },
  {
    path:'/news',
    component:News
  },
  {
    path:'/address',
    component:Address
  },
  {
    path:'/path',
    component:Path
  },
  {
    path:'/invitation',
    component:Invitation
  },
  {
    path:'/senst',
    component:Senst
  },
  {
    path:'/lets',
    component:Lets
  },
  {
    path:'/Register',
    component:Register
  },
  {
    path:'/setting',
    component:Setting
  },
  {
    path:'/firste',
    component:Firste
  },
  {
    path:'/min/:fid',
    component:Min
  },
  {
    path:'/OrderForm',
    component:OrderForm
  },
  {
    path:'/login',
    component:Login
  },
  {
    path:'/me',
    component:Me
  },
  {
    path:'/tabbar',
    component: Tabbar
  },
  {
    path: '/',
    component: Index
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
