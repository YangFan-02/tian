<template>
  <div>
    <!-- 顶部导航栏开始 -->
    <mt-header title="登录">
      <router-link to="/me" slot="left">
        <mt-button icon="back"></mt-button>
      </router-link>
    </mt-header>
    <!-- 顶部导航栏结束 -->
    <!-- 用户名 -->
    <mt-field
      type="text"
      label="用户名"
      placeholder="请输入用户名"
      disableClear
      v-model="username">
    </mt-field>
    <!-- 密码框 -->
    <mt-field
      type="password"
      label="密码"
      placeholder="请输入密码"
      :attr="{maxlength:'20',autocomplete:'off'}"
      v-model="password"
    ></mt-field>
    <!-- 注册文本框结束 -->
    <!-- 注册按钮开始 -->
    <mt-button type="danger" size="large" @click="handle">登录</mt-button>
    <!-- 注册按钮结束 -->
  </div>
</template>
<script>
export default {
  data(){
    return{
      username:'',
      password:'',
    }
  },
  methods:{
    handle(){
      let usernameRexExp = /^[a-zA-Z0-9_]{6,12}$/;
      if(usernameRexExp.test(this.username)){
        // return true;
      }else{
        this.$totast({
          message:"用户名"
        })
      }
    },
  },
}
</script>