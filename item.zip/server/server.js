//加载Express模块
const express = require("express");
//加载CORS模块
const cors = require("cors");
//加载body-parser中间件
const bodyParser = require('body-parser');

//加载MySQL模块
const mysql = require("mysql");
//创建MySQL连接池
const pool = mysql.createPool({
  //数据库服务器的地址
  host: "127.0.0.1",
  //数据库服务器的端口号
  port: 3306,
  //数据库用户的用户名
  user: "root",
  //数据库用户的密码
  password: "",
  //数据库名称
  database: "xboss",
  //数据库的编码方式
  charset: "utf8",
  //支持的最大连接数
  connectionLimit: 20,
});

//创建Express对象
const app = express();

//使用body-parser中间件
app.use(bodyParser.urlencoded({
  extended: false
}))

//使用CORS模块
app.use(
  cors({
    origin: ["http://127.0.0.1:8080", "http://localhost:8080"],
  })
);

app.get('/carousel',(req,res)=>{
  let sql = 'SELECT cid ,img,href FROM carousel';
  pool.query(sql,(err,results)=>{
    if(err) throw err;
    res.send({ message: "查询成功", code: 1, results: results });
  })
});
//首页导航接口
app.get('/index_nav',(req,res)=>{
    let sql = 'SELECT nid,nav_name FROM index_nav';
    pool.query(sql, (err, results) => {
        if (err) throw err;
        res.send({ message: "查询成功", code: 1, results: results });
      });
    });
  //获取内容信息
  app.get('/index',(req,res)=>{
    let nid = req.query.nid;
    //指定的SQL执行语句
    let sql = 'SELECT fid,fname,images,phone,address,saless,hours FROM mfood WHERE nav_id=? ';
    pool.query(sql,[nid],(err,results)=>{
        if(err) throw err;
        res.send({message:"查询成功",code:1,results:results});
    });
   // res.send("ok");
  });
  app.get('/min',(req,res)=>{
    let fid = req.query.fid;
    let sql = 'SELECT fid,title,sales,likes,price,product_img FROM mfood INNER JOIN xboss_product ON fname_id = fid where fid=?';
      pool.query(sql,[fid],(err,results)=>{
        if(err) throw err; 
        res.send({message:'查询成功',code:1,results:results})  
      })
      //res.send("ok");
  });
  
//用户登录接口
app.post('/logi',(req,res) => {
  //1.获取用户名及密码信息
  let username = req.body.username;
  let password = req.body.password;
  //2.以用户名和密码为条件进行查找
  let sql = 'SELECT id,username,nickname FROM user WHERE username=? AND password=?';
  pool.query(sql,[username,password],(err,results) => {
    if (err) throw err;
    if (results.length == 0) {
      res.send({ message: '登录失败', code: 0 });
    } else {
      res.send({ message: '登录成功', code: 1 });
    }
  });
});


//用户注册接口
app.post('/register',(req,res)=>{
  let username = req.body.username;
  let password = req.body.password;
  let sql = "SELECT id,username FROM user WHERE username=?";
  pool.query(sql,[username],(err,results)=>{
    if(err) throw err;
    if(results.length == 0){
        sql = "INSERT INTO user SET username=?,password=?";
        pool.query(sql,[username,password],(err,results)=>{
          if(err) throw err;
          res.send({message:'注册成功',code:1});
        });
    }else{
      res.send({message:'用户名已存在',code:0})
    }
  })
})


//新增地址
app.post('/address',(req,res)=>{
  let receiver = req.body.receiver;
  let cellphone = req.body.cellphone;
  let address = req.body.address;
  let sql = "INSERT INTO xboss_receiver_address (receiver, cellphone,address) VALUES (?,?,?)";
  // let sql = "INSERT INTO user SET receiver=?,cellphone=?,address=?";
  pool.query(sql,[receiver,cellphone,address],(err,results)=>{
    if(err) throw err;
    res.send({message:'注册成功',code:1})
  })
})

//管理地址
app.get('/path',(req,res)=>{
  let sql = "SELECT * FROM xboss_receiver_address";
  pool.query(sql,(err,results)=>{
    res.send({message:"查询成功",code:1,results:results})
  })
})

//指定监听端口号
app.listen(3000, () => {
    console.log("app is runing...");
  });
  